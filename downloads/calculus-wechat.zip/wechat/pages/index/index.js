Page({
 data:{last:null,chapters:[{n:1,title:'动中取静',name:'极限',art:'limits',label:'第一回'},{n:2,title:'投桃报李',name:'微分',art:'derivatives',label:'第二回'},{n:4,title:'聚沙成丘',name:'积分',art:'integrals',label:'第三回'},{n:5,title:'未竟',name:'应用',art:'applications',label:'第四回'}]},
 onShow(){this.setData({last:wx.getStorageSync('lastChapter')||null});},
 open(e){wx.navigateTo({url:'/course'+e.currentTarget.dataset.n+'/pages/read/read'});},
 resume(){if(this.data.last)wx.navigateTo({url:'/course'+this.data.last.number+'/pages/read/read'});},
 onShareAppMessage(){return {title:'微积分 · 山海问道',path:'/pages/index/index'};}
});
