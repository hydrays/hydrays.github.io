Page({data:{chapter:require('./data.json')}});
