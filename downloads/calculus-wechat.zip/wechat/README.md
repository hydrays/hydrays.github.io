# 微积分 · 山海问道

原生微信小程序阅读工程，包含卷首与四回正文、章节目录、字号调整、按小节保存书签、例题提示与解答。

## 导入

1. 安装微信官方开发者工具并用微信扫码登录。
2. 导入本目录（`project.config.json` 所在目录），项目类型选小程序。
3. 当前 AppID 为 `touristappid`，选择测试号/无 AppID 模式进行本地调试。若工具要求申请测试号，使用工具提供的测试号替换。
4. 编译首页 `pages/index/index`。分别检查启程和四回、目录跳转、例题展开以及手机预览。

目前尚无正式小程序账号，不能提交审核或公开上线。注册后提供 AppID 即可继续；不需要提供密码或 AppSecret。正式发布前还需在微信后台按所选主体与类目完成平台要求的资料及备案，并完成真机验收。

## 阅读说明

文字随小程序分包提供；公式与插图通过 HTTPS 从 `https://hydrays.github.io/mini-assets/` 加载，需要联网。此版本不使用 web-view。视频按钮复制 B 站链接，网页版按钮复制相应章节链接；三维互动演示使用网页版。微信开发者工具与真机尚未验收，生成数据与阅读逻辑已进行静态及单元校验。

无登录、无服务器数据库、无统计 SDK。续读和字体设置只保存在设备本地。

## 更新

在工作区根目录运行网页构建，然后依次执行 `tools/mini-extract.py`、`tools/mini-assets.cjs`、`tools/mini-build.py`、`tools/mini-check.cjs`。需要 Python beautifulsoup4、Node mathjax-full 3.2.2 与 sharp。转换资源随后随网页发布。不要手工修改各分包的 data.json。
