Component({
 properties:{chapter:{type:Object,observer(value){if(!value||!value.blocks)return;wx.setNavigationBarTitle({title:value.title});wx.setStorageSync('lastChapter',{number:value.number,title:value.title});const saved=wx.getStorageSync('bookmark-'+value.number);this.setData({fontSize:wx.getStorageSync('readerFontSize')||18,bookmark:saved||''});}}},
 data:{fontSize:18,menu:false,anchor:'',bookmark:'',expanded:{}},
 methods:{
  solution(e){const id=e.currentTarget.dataset.id;this.setData({['expanded.'+id]:!this.data.expanded[id]});},
  toggleMenu(){this.setData({menu:!this.data.menu});},
  jump(e){const id=e.currentTarget.dataset.id;this.setData({anchor:id,menu:false,bookmark:id});wx.setStorageSync('bookmark-'+this.data.chapter.number,id);},
  restore(){if(this.data.bookmark)this.setData({anchor:this.data.bookmark});},
  resize(){const size=this.data.fontSize===22?16:this.data.fontSize+2;this.setData({fontSize:size});wx.setStorageSync('readerFontSize',size);},
  copy(e){wx.setClipboardData({data:e.currentTarget.dataset.url||this.data.chapter.web,success(){wx.showToast({title:'链接已复制',icon:'success'});}});},
  navigate(e){wx.redirectTo({url:'/course'+e.currentTarget.dataset.n+'/pages/read/read'});},
  home(){wx.reLaunch({url:'/pages/index/index'});}
 }
});
